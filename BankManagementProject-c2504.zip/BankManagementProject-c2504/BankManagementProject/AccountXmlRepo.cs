﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace BankManagementProject
{
    /// <summary>
    /// Represents a repository for managing accounts using XML storage.
    /// </summary>
    public class AccountXmlRepo : IAccountRepo
    {
        private static AccountXmlRepo _instance;
        private const string FilePath = "accounts.xml"; // File path for XML storage

        public ObservableCollection<AccountModel> accounts { get; private set; }

        public static AccountXmlRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AccountXmlRepo();
                    _instance.LoadAccounts(); // Load accounts from XML on initialization
                }
                return _instance;
            }
        }

        private AccountXmlRepo()
        {
            accounts = new ObservableCollection<AccountModel>();
        }

        public void Create(AccountModel accModel)
        {
            try
            {
                accounts.Add(accModel);
                SaveAccounts(); // Save to XML after adding
            }
            catch (Exception ex)
            {
                throw new AccountException("Error in creating account", ex);
            }
        }

        public void UpdateAccount(AccountModel accModel)
        {
            try
            {
                var existingAccount = accounts.FirstOrDefault(a => a.AccNo == accModel.AccNo);
                if (existingAccount != null)
                {
                    existingAccount.Address = accModel.Address;
                    SaveAccounts(); // Save to XML after updating
                }
                else
                {
                    throw new AccountException("Account doesn't exist");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ObservableCollection<AccountModel> ReadAllAccount()
        {
            return accounts;
        }

        public void DeleteAccount(AccountModel accModel)
        {
            try
            {
                var existingAccount = accounts.FirstOrDefault(a => a.AccNo == accModel.AccNo);
                if (existingAccount != null)
                {
                    existingAccount.IsActive = false;
                    SaveAccounts(); // Save to XML after deletion
                }
                else
                {
                    throw new AccountException("Account doesn't exist");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Deposit(int acNo, int Amount)
        {
            try
            {
                var account = accounts.FirstOrDefault(a => a.AccNo == acNo);
                if (account != null)
                {
                    account.Balance += Amount;
                    account.LastTransactionDate = DateTime.Now;
                    account.TransactionCount++;
                    SaveAccounts(); // Save to XML after deposit
                }
                else
                {
                    throw new AccountException("Account Not Found, Please input a valid account number");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Withdraw(int acNo, int Amount)
        {
            try
            {
                var account = accounts.FirstOrDefault(a => a.AccNo == acNo);
                if (account != null)
                {
                    if (account.Balance < Amount)
                    {
                        throw new AccountException("Insufficient balance");
                    }
                    account.Balance -= Amount;
                    account.LastTransactionDate = DateTime.Now;
                    account.TransactionCount++;
                    SaveAccounts(); // Save to XML after withdrawal
                }
                else
                {
                    throw new AccountException("Account Not Found, Please input a valid account number");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CalculateInterestAndUpdateBalance()
        {
            throw new NotImplementedException();
        }

        public ObservableCollection<AccountModel> ReadActiveAccount()
        {
            return new ObservableCollection<AccountModel>(accounts.Where(a => a.IsActive));
        }

        public ObservableCollection<AccountModel> ReadInactiveAccount()
        {
            return new ObservableCollection<AccountModel>(accounts.Where(a => !a.IsActive));
        }

        private void LoadAccounts()
        {
            if (File.Exists(FilePath))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<AccountModel>));
                using (FileStream fileStream = new FileStream(FilePath, FileMode.Open))
                {
                    var loadedAccounts = (List<AccountModel>)serializer.Deserialize(fileStream);
                    foreach (var account in loadedAccounts)
                    {
                        accounts.Add(account);
                    }
                }
            }
        }
        private void SaveAccounts()
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<AccountModel>));
            using (FileStream fileStream = new FileStream(FilePath, FileMode.Create))
            {
                // Convert the ObservableCollection to a List for serialization
                var accountList = accounts.ToList();
                serializer.Serialize(fileStream, accountList);
            }
        }
    }
}