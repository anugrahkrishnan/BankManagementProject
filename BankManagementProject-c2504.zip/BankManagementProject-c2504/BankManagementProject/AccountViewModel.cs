﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;



namespace BankManagementProject
{
    public delegate void DWidnowClose();

    // <summary>
    /// Represents a view model for managing accounts.
    /// </summary>
    /// 
    public class AccountViewModel : INotifyPropertyChanged, IDataErrorInfo
    {
        public DWidnowClose NewWindowClose;
        public DWidnowClose EditWindowClose;

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private int _filter;
        public int Filter
        {
            get
            {
                return _filter;
            }
            set
            {
                _filter = value; OnPropertyChanged(nameof(Filter));
            }
        }
        private int _accountNumber;
        public int AccountNumber
        {
            get { return _accountNumber; }
            set
            {
                _accountNumber = value;
                OnPropertyChanged(nameof(AccountNumber));
            }

        }

        private int _amount;

        public int Amount
        {
            get { return _amount; }
            set
            {
                _amount = value;
                OnPropertyChanged(nameof(Amount));
            }
        }

        private AccountModel _newAccount = null;
        public AccountModel NewAccount
        {
            get => _newAccount;
            set { _newAccount = value; OnPropertyChanged(nameof(NewAccount)); }
        }
        //
        private AccountModel _selectedAccount = null;
        public AccountModel SelectedAccount
        {
            get => _selectedAccount;
            set { _selectedAccount = value; OnPropertyChanged(nameof(SelectedAccount)); }
        }
        

        private IAccountRepo _repo = new AccountMemoryRepo();
        public ObservableCollection<AccountModel> Accounts
        {
            get
            {
                switch (Filter)
                {
                    case 1:
                        Filter = 0;
                        return _repo.ReadActiveAccount();

                    case 2:
                        Filter = 0;
                        return _repo.ReadInactiveAccount();

                    default:
                        return _repo.ReadAllAccount();
                        
                }
          
            }
            
        }
        public ICommand CreateCommand { get; }
        public ICommand UpdateCommand { get; }
        public ICommand DeleteCommand { get; }

        public ICommand WithdrawCommand { get; }
        public ICommand DepositCommand { get; }
        //public ICommand ReadAllCommand { get; }

        public ICommand ReadActiveCommand { get; }
        public ICommand ReadInactiveCommand { get; }

        

        public AccountViewModel()
        {
            this.NewAccount = new AccountModel
            {
                AccNo = 0,
                Name = "",
                Balance = 0,
                AccType = "savings",
                Email = " sample@gmail.com",
                PhNo = "xxxx-xxxx",
                Address = "",
                IsActive = true,
                InterestPercentage = "0",
                TransactionCount = 0,
                LastTransactionDate = DateTime.Now
            };



            CreateCommand = new RelayCommand(Create,()=> CanCreate());
            UpdateCommand = new RelayCommand(Update);
            DeleteCommand = new RelayCommand(Delete);
            WithdrawCommand = new RelayCommand(Withdraw);
            DepositCommand = new RelayCommand(Deposit);
            
            ReadActiveCommand = new RelayCommand(ReadActive);
            ReadInactiveCommand = new RelayCommand(ReadInactive);
        }
        private bool CanCreate()
        {
            return (Balance > 0)&&(Email.Length !=0);
        }
        public void Create()
        {
            AccountModel newAccount = new AccountModel
            {
                AccNo = NewAccount.AccNo,
                Name = NewAccount.Name,
                Balance = NewAccount.Balance,
                AccType = NewAccount.AccType,
                Email = NewAccount.Email,
                PhNo = NewAccount.PhNo,
                Address = NewAccount.Address,
                IsActive = NewAccount.IsActive,
                InterestPercentage = NewAccount.InterestPercentage,
                TransactionCount = NewAccount.TransactionCount,
                LastTransactionDate = NewAccount.LastTransactionDate
            };
            var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                    caption: "Confirm",
                    button: MessageBoxButton.YesNo,
                    icon: MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }
            _repo.Create(newAccount);
            this.NewAccount = new AccountModel { AccNo = 0, Name = "", Balance = 0, AccType = "", Email = "", PhNo = "", Address = "", IsActive = false, InterestPercentage = "0", TransactionCount = 0, LastTransactionDate = DateTime.Now };
            
            result = MessageBox.Show(messageBoxText: "Created Successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
            Logger.log.Info($"An account with acoount number {newAccount.AccNo} has been created successfully");

            if (NewWindowClose != null)
            {
                NewWindowClose();
            }
        }

        public void Update()
        {
            if (this.SelectedAccount == null)
            {
                return;
            }

            _repo.UpdateAccount(this.SelectedAccount);
            this.SelectedAccount = this.SelectedAccount;
            var result = MessageBox.Show(messageBoxText: "Updated Successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
            Logger.log.Info($"Account {SelectedAccount.AccNo} is updated successfully");

            if (EditWindowClose != null)
            {
                EditWindowClose();
            }
        }
        public void Delete()
        {
            if (this.SelectedAccount == null)
            {
                return;
            }
            _repo.DeleteAccount(this.SelectedAccount);
            //this.Accounts.Remove(this.SelectedAccount);
            this.SelectedAccount = null;
            Logger.log.Info($"Account {SelectedAccount.AccNo} is marked as deleted successfully");
        }
        public void Withdraw()
        {
            var result = MessageBox.Show(messageBoxText: "Are you sure to Withdraw?",
                   caption: "Confirm",
                   button: MessageBoxButton.YesNo,
                   icon: MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }
            _repo.Withdraw(AccountNumber, Amount);

            this.AccountNumber = 0;
            this.Amount = 0;
            Logger.log.Info($"Withdrawed {Amount} rupees Successfully from account {AccountNumber}");
        }
        public void Deposit()
        {
            var result = MessageBox.Show(messageBoxText: "Are you sure to Deposit?",
                   caption: "Confirm",
                   button: MessageBoxButton.YesNo,
                   icon: MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }
            _repo.Deposit(AccountNumber, Amount);
            Logger.log.Info($"Deposited {Amount} rupees Successfully to account {AccountNumber}");


            this.AccountNumber = 0;
            this.Amount = 0;
        }

        public void ReadActive()
        {
            Filter = 1;
            OnPropertyChanged(nameof(Accounts));
        }

        public void ReadInactive()
        {
            Filter = 2;
            OnPropertyChanged(nameof(Accounts));

        }

        public int CRUD { get; set; } = 1;
        public string Error => null;

        public string this[string columnName]
        {
            get
            {
                AccountModel opAccount = CRUD == 1 ? NewAccount : SelectedAccount;
                string errorMsg = null;
                switch(columnName)
                {
                    case nameof(opAccount.Balance):
                        if (opAccount.Balance < 0)
                        {
                            errorMsg = "Balance should not be negative";
                        }
                        break;
                    case nameof(opAccount.Email):
                        if(opAccount.Email.Length <= 0)
                        {
                            errorMsg = "Enter Email";
                        }
                        break;
                }
                return errorMsg;
            }
        }

        public decimal Balance
        {
            get
            {
                AccountModel opAccount = CRUD == 1 ? NewAccount : SelectedAccount;
                return opAccount.Balance;
            }
            set
            {
                AccountModel opAccount = CRUD == 1 ? NewAccount : SelectedAccount;
                opAccount.Balance = value;
                OnPropertyChanged(nameof(Balance));

            }
        }
        public string Email
        {
            get
            {
                AccountModel opAccount = CRUD == 1 ? NewAccount : SelectedAccount;
                return opAccount.Email;
            }
            set
            {
                AccountModel opAccount = CRUD == 1 ? NewAccount : SelectedAccount;
                opAccount.Email = value;
                OnPropertyChanged(nameof(Email));

            }
        }
    }

}